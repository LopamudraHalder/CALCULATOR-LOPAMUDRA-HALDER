package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    Button Addition, Subtraction, Multiplication, Division;
    EditText et1,et2,et3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Addition=(Button)findViewById(R.id.btnAdd);
        Subtraction=(Button)findViewById(R.id.btnSubtract);
        Multiplication=(Button)findViewById(R.id.btnMultiply);
        Division=(Button)findViewById(R.id.btnDivision);
        et1=(EditText)findViewById(R.id.ed1);
        et2=(EditText)findViewById(R.id.ed2);
        et3=(EditText)findViewById(R.id.ed3);

        Addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {

                    try
                    {
                        et1.getText().toString();
                        et2.getText().toString();
                        double a1=Double.valueOf(et1.getText().toString());
                        double a2=Double.valueOf(et2.getText().toString());
                        double a3;
                        a3=a1+a2;
                        et3.setText(String.valueOf(a3));
                    }
                    catch(Exception e)
                    {
                        Toast.makeText(MainActivity.this, "Please enter two numbers.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        Subtraction.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try
                {
                    et1.getText().toString();
                    et2.getText().toString();
                    double a1 = Double.valueOf(et1.getText().toString());
                    double a2 = Double.valueOf(et2.getText().toString());
                    double a3;
                    a3 = a1 - a2;
                    et3.setText(String.valueOf(a3));
                }
                catch(Exception e)
                {
                    Toast.makeText(MainActivity.this, "Please enter two numbers.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Multiplication.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                try
                {
                    et1.getText().toString();
                    et2.getText().toString();
                    double a1 = Double.valueOf(et1.getText().toString());
                    double a2 = Double.valueOf(et2.getText().toString());
                    double a3;
                    a3 = a1 * a2;
                    et3.setText(String.valueOf(a3));
                }
                catch (Exception e)
                {
                    Toast.makeText(MainActivity.this, "Please enter two numbers.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Division.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                try {

                    et1.getText().toString();
                    et2.getText().toString();
                    double a1 = Double.valueOf(et1.getText().toString());
                    double a2 = Double.valueOf(et2.getText().toString());
                    double a3;
                    a3 = a1 / a2;
                    et3.setText(String.valueOf(a3));
                }
                catch(Exception e)
                {
                    Toast.makeText(MainActivity.this, "Please enter two numbers.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        class generate_exception extends Exception
        {
            generate_exception(String msg)
            {
                super(msg);
            }
        }
        class action
        {
            public void gen_exp(String a, String b) throws generate_exception
            {
                if(a.equals("") || a.equals("")) {
                    throw new generate_exception("Enter proper number.");
                }
            }
        }
    }
}
